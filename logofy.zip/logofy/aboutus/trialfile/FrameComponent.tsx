import { FunctionComponent } from 'react';
import styles from './FrameComponent.module.css';
const FrameComponent:FunctionComponent = () => {
  	
  	return (
    		<div className={styles.groupParent}>
      			<div className={styles.parent}>
        				<div className={styles.div}>
          					<div className={styles.child} />
          					<div className={styles.vectorParent}>
            						<img className={styles.groupChild} alt="" src="Ellipse 3.svg" />
            						<img className={styles.groupItem} alt="" src="Line 1.svg" />
            						<div className={styles.wrapper}>
              							<b className={styles.b}>5</b>
            						</div>
          					</div>
          					<div className={styles.asYourBusiness1}>As your business grows, we'll work with you to scale your software and accommodate increasing demands.</div>
          					</div>
          					<div className={styles.div1}>
            						<div className={styles.item} />
            						<div className={styles.vectorGroup}>
              							<img className={styles.groupInner} alt="" src="Ellipse 3.svg" />
              							<img className={styles.lineIcon} alt="" src="Line 1.svg" />
              							<div className={styles.frame}>
                								<b className={styles.b1}>4</b>
              							</div>
            						</div>
            						<div className={styles.wellMeticulouslyPrepare1}>We'll meticulously prepare for a successful launch, ensuring a smooth transition from development to deployment.</div>
            						</div>
            						<div className={styles.div2}>
              							<div className={styles.inner} />
              							<div className={styles.vectorParent}>
                								<img className={styles.groupChild} alt="" src="Ellipse 3.svg" />
                								<img className={styles.groupItem} alt="" src="Line 1.svg" />
                								<div className={styles.wrapper}>
                  									<b className={styles.b}>3</b>
                								</div>
              							</div>
              							<div className={styles.ourExpertDevelopers1}>Our expert developers will turn your approved design into a robust and scalable software solution.</div>
            						</div>
            						<div className={styles.div3}>
              							<div className={styles.ellipseDiv} />
              							<div className={styles.vectorGroup}>
                								<img className={styles.groupInner} alt="" src="Ellipse 3.svg" />
                								<img className={styles.lineIcon} alt="" src="Line 1.svg" />
                								<div className={styles.frame}>
                  									<b className={styles.b1}>2</b>
                								</div>
              							</div>
              							<div className={styles.ourSkilledDesigners1}>Our skilled designers will craft visually stunning and intuitive user interfaces that enhance the user experience.</div>
            						</div>
            						<div className={styles.div4}>
              							<div className={styles.child1} />
              							<div className={styles.vectorParent1}>
                								<img className={styles.groupChild4} alt="" src="Ellipse 3.svg" />
                								<img className={styles.groupChild5} alt="" src="Line 1.svg" />
                								<div className={styles.wrapper2}>
                  									<b className={styles.b}>1</b>
                								</div>
                								<b className={styles.ideate}>Ideate</b>
                								<b className={styles.scale}>Scale</b>
                								<b className={styles.design}>Design</b>
                								<b className={styles.develop}>Develop</b>
                								<b className={styles.launch}>Launch</b>
              							</div>
              							<div className={styles.letsBrainstormTogether1}>Let's brainstorm together and explore creative ideas to solve your unique challenges.</div>
              							</div>
              							<b className={styles.designBuildAnd1}>Design, build, and scale your vision with us</b>
            						</div>
          					</div>);
          					};
          					
          					export default FrameComponent;
          					